﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {

        public Form1()
        {   
      
        InitializeComponent();
        }
       
        private void button1_Click(object sender, EventArgs e)
        {
            double a = 1, b = 6 * Math.PI, h = .1, x, y;
            this.chart1.Series[0].Points.Clear();
            x = a;
            while (x <= b)
            {
                y = Math.Log(x) + Math.Log10(x);
                this.chart1.Series[0].Points.AddXY(x, y);
                x += h;
            }
            int wX;
            int hX;
            double xF, yF;
            double step;

            wX = pictureBox1.Width;
            hX = pictureBox1.Height; //Значение высоты

            // Система Координат
            Bitmap flag = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            Graphics flagGraphics = Graphics.FromImage(flag);
            System.Drawing.Pen myPen;
            myPen = new System.Drawing.Pen(System.Drawing.Color.Black);
            flagGraphics.DrawLine(myPen, 0, (int)(hX / 2), wX , (int)(hX / 2));
            flagGraphics.DrawLine(myPen, 0, 0, 0,hX);

            // График
            for (step = 1; step <= 10; step += 0.1)
            {
                xF = (step * 25) + 0;
                double tmp = Math.Log(step) + Math.Log10(step);
                tmp *= 50;
                yF = (int)(hX / 2) - tmp;
                flag.SetPixel((int)xF, (int)yF, Color.Red);
            }



            pictureBox1.Image = flag;
            label1.Text = "Function ln(x) + lg(x)";
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

      
    }
 }

